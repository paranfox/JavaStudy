package edu.java.booklist;

public class BookserviceDAOImple implements BookserviceDAO {

}
