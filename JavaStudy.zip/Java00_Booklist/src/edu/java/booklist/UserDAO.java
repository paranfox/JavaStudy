package edu.java.booklist;

public interface UserDAO {

}
