package edu.java.booklist;

import java.util.ArrayList;

public class BookslistDAOImple implements BookslistDAO{

	@Override
	public ArrayList<AdminVO> bookselect() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BookslistVO bookselect(int index) {
		// TODO Auto-generated method stub
		return null;
	}

}
