package edu.java.booklist;

import java.util.ArrayList;

public class AdminDAOImple implements AdminDAO {

	@Override
	public int login(AdminVO vo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int Logout(AdminVO vo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ArrayList<AdminVO> adminselect() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int adminUpdate(AdminVO vo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int bookinsert(BookslistVO vo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int bookupdate(int index, BookslistVO vo) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	@Override
	public int bookdelete(int index) {
		// TODO Auto-generated method stub
		return 0;
	}

}
