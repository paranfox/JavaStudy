package edu.java.booklist;

public interface BookserviceDAO { //도서 대여/관리 기능 메서드 정의
//	BookserviceDAO.java
//	: DAO Implement 클래스. 도서 대여/관리 기능 메서드 구현
//	 DB에 접근하여 데이터 등록/검색/수정/삭제 수행
	// 도서 대여 상태
	
	// 도서 대여 시간
	
	// 도서 반납 시간
	
	// 도서 
	
} // end BookserviceDAO
