package edu.java.homework;

public class Printer {

	public Printer() {
		// TODO Auto-generated constructor stub
	}

	public void println(int i) {
		System.out.println(i);
	}

	public void println(boolean b) {
		System.out.println(b);
	}

	public void println(double d) {
		System.out.println(d);
	}

	public void println(String s) {
		System.out.println(s);
	}

} // end Printer
