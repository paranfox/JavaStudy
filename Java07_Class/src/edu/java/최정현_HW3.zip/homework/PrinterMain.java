package edu.java.homework;

public class PrinterMain {

	public static void main(String[] args) {
		Printer pr = new Printer();
		pr.println(10);
		pr.println(true);
		pr.println(5.7);
		pr.println("홍길동");

	} // end main()

} // end PrinterMain
