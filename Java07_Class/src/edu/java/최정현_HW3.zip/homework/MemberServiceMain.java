package edu.java.homework;

public class MemberServiceMain {

	public static void main(String[] args) {
		MemberService rect1 = new MemberService();
		
		boolean result = rect1.login("hong", "12345");
		if(result) {
			System.out.println("로그인 되었습니다.");
			rect1.logout("hong");
		} else {
			System.out.println("id 또는 password가 올바르지 않습니다.");
		}
		
		
	} // end main()

} // end MemberServiceMain
